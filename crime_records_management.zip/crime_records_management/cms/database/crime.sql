-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.0.27-community-nt - MySQL Community Edition (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             12.7.0.6850
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for crime
CREATE DATABASE IF NOT EXISTS `crime` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `crime`;

-- Dumping structure for table crime.crime_category_nature_master
CREATE TABLE IF NOT EXISTS `crime_category_nature_master` (
  `nature_id` int(11) NOT NULL auto_increment,
  `category_id` int(11) NOT NULL,
  `nature_name` varchar(150) NOT NULL,
  PRIMARY KEY  (`nature_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table crime.crime_category_nature_master: ~2 rows (approximately)
REPLACE INTO `crime_category_nature_master` (`nature_id`, `category_id`, `nature_name`) VALUES
	(1, 1, 'theft'),
	(2, 1, 'robbery');

-- Dumping structure for table crime.crime_charge_sheet_master
CREATE TABLE IF NOT EXISTS `crime_charge_sheet_master` (
  `charge_sheet_no` int(11) NOT NULL auto_increment,
  `charge_sheet_name` varchar(150) NOT NULL,
  `charge_sheet_details` text,
  `first_no` varchar(50) NOT NULL,
  `produced_court_no` varchar(50) NOT NULL,
  `sheet_file` longblob,
  PRIMARY KEY  (`charge_sheet_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table crime.crime_charge_sheet_master: ~0 rows (approximately)

-- Dumping structure for table crime.department_employee_master
CREATE TABLE IF NOT EXISTS `department_employee_master` (
  `employee_id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `date_of_joining` date NOT NULL,
  `address` varchar(150) default NULL,
  `email` varchar(150) default NULL,
  `phone_no` varchar(15) default NULL,
  PRIMARY KEY  (`employee_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone_no` (`phone_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table crime.department_employee_master: ~2 rows (approximately)
REPLACE INTO `department_employee_master` (`employee_id`, `name`, `designation`, `department`, `dob`, `date_of_joining`, `address`, `email`, `phone_no`) VALUES
	(1001, 'balakumar', 'sub inspector', 'investigation', '1987-02-02', '2023-03-02', 'west main street, thanjavur', 'bala123@gmail.com', '7358978226'),
	(1002, 'arun kumar', 'inspector', 'patrol', '1987-04-03', '2003-05-23', 'balopa nandhavanam, thanjavur', 'arun123@gmail.com', '7358978220');

-- Dumping structure for table crime.designation_master
CREATE TABLE IF NOT EXISTS `designation_master` (
  `designation_id` int(11) NOT NULL auto_increment,
  `designation_name` varchar(255) NOT NULL,
  `designation_description` text,
  PRIMARY KEY  (`designation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table crime.designation_master: ~2 rows (approximately)
REPLACE INTO `designation_master` (`designation_id`, `designation_name`, `designation_description`) VALUES
	(101, 'viki', 'manager of master'),
	(102, 'arun', 'supervisor');

-- Dumping structure for table crime.evidence_type_master
CREATE TABLE IF NOT EXISTS `evidence_type_master` (
  `evidence_id` int(11) NOT NULL auto_increment,
  `evidence_name` varchar(150) NOT NULL,
  `description` text,
  PRIMARY KEY  (`evidence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table crime.evidence_type_master: ~0 rows (approximately)

-- Dumping structure for table crime.investigation_master
CREATE TABLE IF NOT EXISTS `investigation_master` (
  `investigation_id` int(11) NOT NULL auto_increment,
  `start_date` date NOT NULL,
  `end_date` date default NULL,
  PRIMARY KEY  (`investigation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table crime.investigation_master: ~0 rows (approximately)

-- Dumping structure for table crime.victim_fir_master
CREATE TABLE IF NOT EXISTS `victim_fir_master` (
  `victim_fir_id` int(11) NOT NULL auto_increment,
  `crime_nature_id` int(11) NOT NULL,
  `address` text NOT NULL,
  `location_details` text NOT NULL,
  `victim_id` int(11) NOT NULL,
  `investigation_officer_id` int(11) NOT NULL,
  `crime_date` date NOT NULL,
  PRIMARY KEY  (`victim_fir_id`),
  KEY `crime_nature_id` (`crime_nature_id`),
  KEY `victim_id` (`victim_id`),
  CONSTRAINT `victim_fir_master_ibfk_1` FOREIGN KEY (`crime_nature_id`) REFERENCES `crime_category_nature_master` (`nature_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table crime.victim_fir_master: ~1 rows (approximately)
REPLACE INTO `victim_fir_master` (`victim_fir_id`, `crime_nature_id`, `address`, `location_details`, `victim_id`, `investigation_officer_id`, `crime_date`) VALUES
	(1, 2, 'west main street, thanajavur', 'chennain', 2, 2, '2003-03-03');

-- Dumping structure for table crime.victim_master
CREATE TABLE IF NOT EXISTS `victim_master` (
  `victim_id` int(11) NOT NULL auto_increment,
  `victim_name` varchar(150) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(150) default NULL,
  `address` varchar(100) default NULL,
  `phone_no` varchar(15) default NULL,
  PRIMARY KEY  (`victim_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone_no` (`phone_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table crime.victim_master: ~2 rows (approximately)
REPLACE INTO `victim_master` (`victim_id`, `victim_name`, `dob`, `email`, `address`, `phone_no`) VALUES
	(1, 'vignesh', '2004-09-28', 'svvignesh867@gmail.com', 'west main street, thanjavur', '7358978226'),
	(2, 'arun', '2005-03-02', 'bala123@gmail.com', 'balopa nandhavanam, thanjavur', '7358978220');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
