from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
import mysql.connector, joblib, re, string
from collections import Counter
from django.utils.timezone import localtime
from django.db.models import Count
from django.http import JsonResponse 
import datetime
# Load trained mode
import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

model = joblib.load(os.path.join(BASE_DIR, 'spam_detector/logistic_spam_model.pkl'))
vectorizer = joblib.load(os.path.join(BASE_DIR, 'spam_detector/tfidf_vectorizer.pkl'))

print("Vectorizer fitted:", hasattr(vectorizer, "idf_"))
print("Features count:", len(vectorizer.get_feature_names_out()))
def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'<.*?>', '', text)
    text = re.sub(r'http\S+|www\S+|https\S+', '', text)
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\s+', ' ', text).strip()
    return text
# Dashboard
@login_required(login_url='login')
def dashboard(request):
    # Hardcoded counts for now
    emails_count = 1000
    spam_count = 350
    accuracy = 96  # optional
    context = {
        'username': request.user.username,
        'emails_count': emails_count,
        'spam_count': spam_count,
        'accuracy': accuracy,
    }
    return render(request, 'spam_detector/dashboard.html', context)
# Register
def register(request):
    message = ''
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        # Using Django auth User model
        if User.objects.filter(username=username).exists():
            message = "Username already exists."
        else:
            User.objects.create_user(username=username, password=password)
            message = "Registration successful! Please login."
    return render(request, 'spam_detector/register.html', {'message': message})
# Login
def user_login(request):
    message = ''
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)  # logs in the user
            return redirect('dashboard')
        else:
            message = 'Invalid username or password'
    return render(request, 'spam_detector/login.html', {'message': message})
# Logout
def user_logout(request):
    logout(request)  # logs out the user
    return redirect('login')
# Email Input Page
@login_required(login_url='login')
def home(request):
    return render(request, 'spam_detector/home.html', {'username': request.user.username})
# Predict Spam
@login_required(login_url='login')
def predict(request):
    if request.method == 'POST':
        # Get textarea input
        email_text = request.POST.get('email_text', '')
        # Get uploaded file (if any)
        uploaded_file = request.FILES.get('email_file')
        if uploaded_file:
            try:
                file_content = uploaded_file.read().decode('utf-8', errors='ignore')
                email_text += "\n" + file_content  # Combine with textarea input
            except Exception as e:
                print("File read error:", e)
        # Clean and vectorize text
        email_clean = clean_text(email_text)
        email_vec = vectorizer.transform([email_clean])
        # Predict
        prediction = model.predict(email_vec)[0]
        probability = model.predict_proba(email_vec)[0]# 🔥 Add this here
        spam_index = list(model.classes_).index('Spam')
        spam_prob = float(round(probability[spam_index] * 100, 2))
        # Save to MySQL history
        conn = mysql.connector.connect(
            host='localhost',
            user='root',
            password='root',
            port=3306,
            database='spam_db'
        )
        c = conn.cursor()
        c.execute(
            "INSERT INTO history (username, email_text, prediction, probability) VALUES (%s,%s,%s,%s)",
            (request.user.username, email_text, prediction, spam_prob)
        )
        conn.commit()
        conn.close()
        return render(request, 'spam_detector/result.html', {
            'prediction': prediction,
            'spam_prob': spam_prob,
            'email_text': email_text
        })
    return redirect('home')
# About/Help
def about(request):
    return render(request, 'spam_detector/about.html')
# History Page
@login_required(login_url='login')
def history(request):
    conn = mysql.connector.connect(host='localhost', port=3306,user='root', password='root', database='spam_db')
    c = conn.cursor()
    c.execute("SELECT email_text, prediction, probability, created_at FROM history WHERE username=%s ORDER BY created_at DESC",
              (request.user.username,))
    data = c.fetchall()
    conn.close()
    return render(request, 'spam_detector/history.html', {'history': data, 'username': request.user.username})
#statistics
'''
@login_required(login_url='login')
def statistics(request):
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='root',
        port=3306,
        database='spam_db'
    )
    # ✅ Use dictionary=True to fetch as dict
    c = conn.cursor(dictionary=True)
    # 1️⃣ Total Emails & Spam/Ham Count
    c.execute("""
        SELECT 
            SUM(CASE WHEN prediction='Spam' THEN 1 ELSE 0 END) AS spam_count,
            SUM(CASE WHEN prediction='Ham' THEN 1 ELSE 0 END) AS ham_count,
            COUNT(*) AS total_count
        FROM history
        WHERE username=%s
    """, (request.user.username,))
    counts = c.fetchone()
    # ✅ Safely extract values (if None → 0)
    spam_count = counts['spam_count'] or 0
    ham_count = counts['ham_count'] or 0
    total_emails = counts['total_count'] or 0
    # 2️⃣ Weekly Spam Trend (last 6 weeks)
    c.execute("""
        SELECT DATE_FORMAT(created_at, '%%Y-%%u') AS week,
               SUM(CASE WHEN prediction='Spam' THEN 1 ELSE 0 END) AS spam_per_week
        FROM history
        WHERE username=%s
        GROUP BY week
        ORDER BY week DESC
        LIMIT 6
    """, (request.user.username,))
    weekly_raw = c.fetchall()
    weekly_raw.reverse()  # old → new order
    weeks = [w['week'] for w in weekly_raw]
    spam_trend = [w['spam_per_week'] for w in weekly_raw]
    # 3️ Top Spam Keywords (basic split)
    c.execute("""
        SELECT email_text
        FROM history
        WHERE username=%s AND prediction='Spam'
    """, (request.user.username,))
    spam_texts = [row['email_text'] for row in c.fetchall()]
    conn.close()
    all_words = []
    for text in spam_texts:
        cleaned = clean_text(text)
        all_words.extend(cleaned.split())
    # Remove stopwords
    stopwords = set(['the','and','to','of','in','a','for','is','on','you','your','with','this','that'])
    
# 🔥 Add Tanglish stopwords
    stopwords.update(['ah','da','pa','la','nga','um'])
    filtered = [w for w in all_words if w not in stopwords]
    top_words = Counter(filtered).most_common(6)
    top_labels = [t[0] for t in top_words]
    top_values = [t[1] for t in top_words]
    context = {
        'username': request.user.username,
        'total_emails': total_emails,
        'spam_count': spam_count,
        'ham_count': ham_count,
        'weeks': weeks,
        'spam_trend': spam_trend,
        'top_labels': top_labels,
        'top_values': top_values,
    }
    return render(request, 'spam_detector/statistics.html', context)'''

@login_required(login_url='login')
def statistics(request):
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='root',
        port=3306,
        database='spam_db'
    )
    c = conn.cursor(dictionary=True)
    # Total counts
    c.execute("""
        SELECT 
            SUM(CASE WHEN prediction='Spam' THEN 1 ELSE 0 END) AS spam_count,
            SUM(CASE WHEN prediction='Ham' THEN 1 ELSE 0 END) AS ham_count,
            COUNT(*) AS total_count
        FROM history
        WHERE username=%s
    """, (request.user.username,))
    counts = c.fetchone()
    spam_count = counts['spam_count'] or 0
    ham_count = counts['ham_count'] or 0
    total_emails = counts['total_count'] or 0
    # Weekly spam trend (last 6 weeks)
    c.execute("""
        SELECT DATE_FORMAT(created_at, '%%Y-%%u') AS week,
               SUM(CASE WHEN prediction='Spam' THEN 1 ELSE 0 END) AS spam_per_week
        FROM history
        WHERE username=%s
        GROUP BY week
        ORDER BY week DESC
        LIMIT 6
    """, (request.user.username,))
    weekly_raw = c.fetchall()
    weekly_raw.reverse()
    weeks = [w['week'] for w in weekly_raw]
    spam_trend = [w['spam_per_week'] for w in weekly_raw]

    # Top spam keywords
    c.execute("""
        SELECT email_text
        FROM history
        WHERE username=%s AND prediction='Spam'
    """, (request.user.username,))
    spam_texts = [row['email_text'] for row in c.fetchall()]
    conn.close()
    all_words = []
    for text in spam_texts:
        cleaned = clean_text(text)
        all_words.extend(cleaned.split())
    stopwords = set(['the','and','to','of','in','a','for','is','on','you','your','with','this','that'])
    stopwords.update(['ah','da','pa','la','nga','um']) 
    filtered = [w for w in all_words if w not in stopwords]
    top_words = Counter(filtered).most_common(6)
    top_labels = [t[0] for t in top_words]
    top_values = [t[1] for t in top_words]
    context = {
        'username': request.user.username,
        'total_emails': total_emails,
        'spam_count': spam_count,
        'ham_count': ham_count,
        'weeks': weeks,
        'spam_trend': spam_trend,
        'top_labels': top_labels,
        'top_values': top_values,
    }
    return render(request, 'spam_detector/statistics.html', context)

  # 🔥 add at top

@login_required(login_url='login')
def ajax_predict(request):
    if request.method == "POST":
        text = request.POST.get('text', '')

        clean_input = clean_text(text)
        vec = vectorizer.transform([clean_input])

        prediction = model.predict(vec)[0]
        probability = model.predict_proba(vec)[0]

        spam_index = list(model.classes_).index('Spam')
        spam_prob = float(round(probability[spam_index] * 100, 2))

        return JsonResponse({
            'prediction': prediction,
            'spam_prob': spam_prob
        })