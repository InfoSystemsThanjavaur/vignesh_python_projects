# spam_detector folder-ல check_pkl.py என்று save பண்ணி run பண்ணு
import joblib, os

BASE = r"D:\Project\Python_Project\email_spam_project\spam_detector"

vec_path   = os.path.join(BASE, "tfidf_vectorizer.pkl")
model_path = os.path.join(BASE, "logistic_spam_model.pkl")

print("=== FILE CHECK ===")
print("Vectorizer exists:", os.path.exists(vec_path))
print("Model exists     :", os.path.exists(model_path))

print("\n=== SIZE CHECK ===")
print("Vectorizer size  :", os.path.getsize(vec_path), "bytes")
print("Model size       :", os.path.getsize(model_path), "bytes")

print("\n=== FITTED CHECK ===")
vec   = joblib.load(vec_path)
model = joblib.load(model_path)
print("Vectorizer fitted:", hasattr(vec, "idf_"))
print("Model fitted     :", hasattr(model, "coef_"))

if hasattr(vec, "idf_"):
    print("Features count   :", len(vec.get_feature_names_out()))
    print("Classes          :", model.classes_)
    print("\n✅ PKL files are GOOD!")
else:
    print("\n❌ Vectorizer NOT fitted — wrong PKL file!")