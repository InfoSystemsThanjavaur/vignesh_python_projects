-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.43 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for spam_db
CREATE DATABASE IF NOT EXISTS `spam_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `spam_db`;

-- Dumping structure for table spam_db.auth_group
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.auth_group: ~0 rows (approximately)

-- Dumping structure for table spam_db.auth_group_permissions
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.auth_group_permissions: ~0 rows (approximately)

-- Dumping structure for table spam_db.auth_permission
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.auth_permission: ~24 rows (approximately)
REPLACE INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
	(1, 'Can add log entry', 1, 'add_logentry'),
	(2, 'Can change log entry', 1, 'change_logentry'),
	(3, 'Can delete log entry', 1, 'delete_logentry'),
	(4, 'Can view log entry', 1, 'view_logentry'),
	(5, 'Can add permission', 2, 'add_permission'),
	(6, 'Can change permission', 2, 'change_permission'),
	(7, 'Can delete permission', 2, 'delete_permission'),
	(8, 'Can view permission', 2, 'view_permission'),
	(9, 'Can add group', 3, 'add_group'),
	(10, 'Can change group', 3, 'change_group'),
	(11, 'Can delete group', 3, 'delete_group'),
	(12, 'Can view group', 3, 'view_group'),
	(13, 'Can add user', 4, 'add_user'),
	(14, 'Can change user', 4, 'change_user'),
	(15, 'Can delete user', 4, 'delete_user'),
	(16, 'Can view user', 4, 'view_user'),
	(17, 'Can add content type', 5, 'add_contenttype'),
	(18, 'Can change content type', 5, 'change_contenttype'),
	(19, 'Can delete content type', 5, 'delete_contenttype'),
	(20, 'Can view content type', 5, 'view_contenttype'),
	(21, 'Can add session', 6, 'add_session'),
	(22, 'Can change session', 6, 'change_session'),
	(23, 'Can delete session', 6, 'delete_session'),
	(24, 'Can view session', 6, 'view_session');

-- Dumping structure for table spam_db.auth_user
CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.auth_user: ~5 rows (approximately)
REPLACE INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
	(1, 'pbkdf2_sha256$870000$TuvcpP2XhiSEEV8vDGZMb5$/mf9hESxCudWQuKcDyvfjA5xRM0Hq18YW4En9NfK93g=', '2025-09-24 08:47:46.607780', 0, 'viki', '', '', '', 0, 1, '2025-09-23 16:39:17.550410'),
	(2, 'pbkdf2_sha256$870000$kUxSUkAhVokYSiapG6cnBM$1g4jbCOnMGNf2jveOEpEWsdwj4GDDI40KVrZHMW42RA=', '2025-12-28 14:48:30.368637', 0, 'svvignesh867@gmail.com', '', '', '', 0, 1, '2025-12-28 14:30:28.942372'),
	(3, 'pbkdf2_sha256$1000000$cKu8VhpB5vZHfN5Y2vQi3I$SWEwbA8UQsuFCXKLDAdUE/EBbOu+WGVBse9IXx5GH5M=', '2026-03-23 05:40:06.836735', 0, 'ara@gmail.com', '', '', '', 0, 1, '2026-03-23 05:39:52.984738'),
	(4, 'pbkdf2_sha256$1000000$URi0K4X1pNCNQA5Ic7S0V7$wTq1Rh5RcFWrtlqaoWOFczCOhdH2mM04e5oy83nHPtE=', '2026-04-21 15:13:36.213718', 0, 'arun123@gmail.com', '', '', '', 0, 1, '2026-04-21 15:12:56.210065'),
	(5, 'pbkdf2_sha256$1000000$w3YlDoQTOyIdwDif5ZQUVt$Qqxb8mn6xgFDhhlduUjgTi0uvd+KbCw4akGh8KCwj6c=', NULL, 0, 'arun', '', '', '', 0, 1, '2026-04-21 15:13:15.034240');

-- Dumping structure for table spam_db.auth_user_groups
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.auth_user_groups: ~0 rows (approximately)

-- Dumping structure for table spam_db.auth_user_user_permissions
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.auth_user_user_permissions: ~0 rows (approximately)

-- Dumping structure for table spam_db.django_admin_log
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.django_admin_log: ~0 rows (approximately)

-- Dumping structure for table spam_db.django_content_type
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.django_content_type: ~6 rows (approximately)
REPLACE INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
	(1, 'admin', 'logentry'),
	(3, 'auth', 'group'),
	(2, 'auth', 'permission'),
	(4, 'auth', 'user'),
	(5, 'contenttypes', 'contenttype'),
	(6, 'sessions', 'session');

-- Dumping structure for table spam_db.django_migrations
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.django_migrations: ~18 rows (approximately)
REPLACE INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
	(1, 'contenttypes', '0001_initial', '2025-09-23 16:38:26.198190'),
	(2, 'auth', '0001_initial', '2025-09-23 16:38:27.072576'),
	(3, 'admin', '0001_initial', '2025-09-23 16:38:27.321932'),
	(4, 'admin', '0002_logentry_remove_auto_add', '2025-09-23 16:38:27.330347'),
	(5, 'admin', '0003_logentry_add_action_flag_choices', '2025-09-23 16:38:27.343289'),
	(6, 'contenttypes', '0002_remove_content_type_name', '2025-09-23 16:38:27.552622'),
	(7, 'auth', '0002_alter_permission_name_max_length', '2025-09-23 16:38:27.650921'),
	(8, 'auth', '0003_alter_user_email_max_length', '2025-09-23 16:38:27.685826'),
	(9, 'auth', '0004_alter_user_username_opts', '2025-09-23 16:38:27.700472'),
	(10, 'auth', '0005_alter_user_last_login_null', '2025-09-23 16:38:27.796378'),
	(11, 'auth', '0006_require_contenttypes_0002', '2025-09-23 16:38:27.802016'),
	(12, 'auth', '0007_alter_validators_add_error_messages', '2025-09-23 16:38:27.812691'),
	(13, 'auth', '0008_alter_user_username_max_length', '2025-09-23 16:38:27.927202'),
	(14, 'auth', '0009_alter_user_last_name_max_length', '2025-09-23 16:38:28.032110'),
	(15, 'auth', '0010_alter_group_name_max_length', '2025-09-23 16:38:28.060671'),
	(16, 'auth', '0011_update_proxy_permissions', '2025-09-23 16:38:28.071636'),
	(17, 'auth', '0012_alter_user_first_name_max_length', '2025-09-23 16:38:28.169659'),
	(18, 'sessions', '0001_initial', '2025-09-23 16:38:28.226755');

-- Dumping structure for table spam_db.django_session
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.django_session: ~2 rows (approximately)
REPLACE INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
	('2y0vobfvbts8llruuo84nh5dt510e386', '.eJxVjMsOwiAQRf-FtSFlKI9x6d5vIAMMUjU0Ke3K-O_apAvd3nPOfYlA21rD1nkJUxZnAeL0u0VKD247yHdqt1mmua3LFOWuyIN2eZ0zPy-H-3dQqddvTcVpCwyD0YxojB4xkXfKjkw5KaJkXLaARTnvmZQdVFIxZiyaARHE-wPWojeu:1vZs4M:yGOLuicjdk9lboAv0nvPRw-JIfy9ADIn-WJ4Juk56t8', '2026-01-11 14:48:30.378590'),
	('i0ope11f3ndczua1slvvtpwazffshbd5', '.eJxVjEEOwiAQRe_C2pDCjAO6dO8ZyACDVA1NSrsy3l2bdKHb_977LxV4XWpYu8xhzOqsUB1-t8jpIW0D-c7tNuk0tWUeo94UvdOur1OW52V3_w4q9_qtCxtP1g8RwLADk9AgG3LkkU7ovPGIR44pU6IodohWSMCVVDI5AFLvD7djNxY:1wFCnA:-sWOzN6CBe8MYkxFdCvaAVdJ_7iEjeiG_CbQviR2LqE', '2026-05-05 15:13:36.218718');

-- Dumping structure for table spam_db.history
CREATE TABLE IF NOT EXISTS `history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email_text` text NOT NULL,
  `prediction` varchar(10) NOT NULL,
  `probability` float NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.history: ~21 rows (approximately)
REPLACE INTO `history` (`id`, `username`, `email_text`, `prediction`, `probability`, `created_at`) VALUES
	(1, 'viki', '', 'Spam', 61.99, '2025-09-23 16:44:58'),
	(2, 'viki', 'Dear Winner,\r\nYour email has been selected in our International Lottery.\r\nTo claim your prize, send your name, address, and bank details.\r\nHurry! Offer valid for 48 hours.', 'Spam', 92.16, '2025-09-23 16:45:13'),
	(3, 'viki', 'Hi Team,\r\nPlease be ready for the project status meeting on Monday at 10 AM.\r\nAgenda and Zoom link are attached.\r\nRegards,\r\nPriya', 'Ham', 7.99, '2025-09-23 16:45:28'),
	(4, 'viki', '', 'Spam', 61.99, '2025-09-23 16:59:00'),
	(5, 'viki', 'Hi Team,\r\nPlease be ready for the project status meeting on Monday at 10 AM.\r\nAgenda and Zoom link are attached.\r\nRegards,\r\nPriya', 'Ham', 7.99, '2025-09-23 16:59:11'),
	(6, 'viki', '', 'Spam', 61.99, '2025-09-23 16:59:18'),
	(7, 'viki', '\nHi Team,\r\nPlease be ready for the project status meeting on Monday at 10 AM.\r\nAgenda and Zoom link are attached.\r\nRegards,\r\nPriya', 'Ham', 7.99, '2025-09-23 17:02:51'),
	(8, 'viki', 'Hi Team,\r\nPlease be ready for the project status meeting on Monday at 10 AM.\r\nAgenda and Zoom link are attached.\r\nRegards,\r\nPriya', 'Ham', 7.99, '2025-09-23 17:09:50'),
	(9, 'viki', 'Dear Winner,\r\n   Your email has been selected in our International Lottery.\r\n   To claim your prize, send your name, address, and bank details.\r\n   Hurry! Offer valid for 48 hours.\r\n', 'Spam', 92.16, '2025-09-23 17:19:57'),
	(10, 'viki', ' <a class="text-sm font-medium hover:text-primary dark:hover:text-primary" href="{% url \'about\' %}">About</a>', 'Spam', 61.99, '2025-09-23 17:20:56'),
	(11, 'viki', ' <a class="text-sm font-medium hover:text-primary dark:hover:text-primary" href="{% url \'about\' %}">About</a>', 'Spam', 61.99, '2025-09-23 17:22:16'),
	(12, 'viki', 'bumber offer going', 'Spam', 68.89, '2025-09-23 18:27:20'),
	(13, 'viki', 'ooferer', 'Spam', 61.99, '2025-09-24 08:48:10'),
	(14, 'svvignesh867@gmail.com', 'An Advanced Email Spam Detection and Classification System Using SVM and Django', 'Spam', 76.18, '2025-12-28 14:49:28'),
	(15, 'ara@gmail.com', '🎉 Congratulations! You won ₹50,000!\r\nDear user,\r\nYou have been selected as a lucky winner. Click the link below to claim your prize immediately.\r\n👉 http://fake-link.com\r\n\r\nHurry! Offer expires today.', 'Spam', 87.9, '2026-03-23 05:42:02'),
	(16, 'ara@gmail.com', 'Subject: Meeting Reminder\r\nHi Viki,\r\nThis is a reminder for tomorrow’s team meeting at 10 AM.\r\nRegards,\r\nManager', 'Ham', 16.99, '2026-03-23 05:42:15'),
	(17, 'ara@gmail.com', '\nSubject: Meeting Reminder\r\nHi Viki,\r\nThis is a reminder for tomorrow’s team meeting at 10 AM.\r\nRegards,\r\nManager', 'Ham', 16.99, '2026-03-23 05:43:33'),
	(18, 'arun123@gmail.com', 'offer venuma', 'Spam', 92.39, '2026-04-22 17:24:29'),
	(19, 'arun123@gmail.com', 'ungaluku offer vanduruku', 'Spam', 94.64, '2026-04-22 17:24:51'),
	(20, 'arun123@gmail.com', 'nalaiki nama, meet panalam', 'Ham', 38.29, '2026-04-22 17:25:05'),
	(21, 'arun123@gmail.com', 'unga amma appa epdi irukanga', 'Spam', 53.49, '2026-04-22 17:33:11');

-- Dumping structure for table spam_db.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table spam_db.users: ~0 rows (approximately)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
